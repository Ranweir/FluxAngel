package com.ranweir.fluxangel

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.widget.RemoteViews
import androidx.media3.common.C
import androidx.media3.common.Player
import coil.imageLoader
import coil.request.ImageRequest
import coil.size.Precision
import coil.size.Scale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Home-screen widget: cover, title, glowing progress bar and prev / play / next. */
class FluxWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.update(context, MusicService.instance?.player)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val p = MusicService.instance?.player ?: return
        when (intent.action) {
            WidgetUpdater.ACTION_PLAY_PAUSE -> if (p.isPlaying) p.pause() else p.play()
            WidgetUpdater.ACTION_NEXT -> p.seekToNextMediaItem()
            WidgetUpdater.ACTION_PREV -> p.seekToPreviousMediaItem()
        }
    }
}

object WidgetUpdater {
    const val ACTION_PLAY_PAUSE = "com.ranweir.fluxangel.WIDGET_PLAY_PAUSE"
    const val ACTION_NEXT = "com.ranweir.fluxangel.WIDGET_NEXT"
    const val ACTION_PREV = "com.ranweir.fluxangel.WIDGET_PREV"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var artKey: String? = null
    private var artBitmap: Bitmap? = null

    private fun ids(ctx: Context): IntArray =
        AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, FluxWidget::class.java))

    fun hasWidgets(ctx: Context) = ids(ctx).isNotEmpty()

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun broadcast(ctx: Context, action: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, action.hashCode(), Intent(ctx, FluxWidget::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Full refresh (song / play state changed). */
    fun update(ctx: Context, p: Player?) {
        val all = ids(ctx)
        if (all.isEmpty()) return
        val manager = AppWidgetManager.getInstance(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_player)
        val meta = p?.mediaMetadata
        val title = meta?.title?.toString()
        val has = p != null && p.mediaItemCount > 0 && !title.isNullOrBlank()
        rv.setTextViewText(R.id.w_title, if (has) title else "Flux Angel")
        rv.setTextViewText(R.id.w_artist, if (has) meta?.artist?.toString().orEmpty() else "Tap to play music")
        rv.setImageViewResource(R.id.w_play, if (p?.isPlaying == true) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        applyProgress(rv, p)

        val key = meta?.artworkUri?.toString()
        if (has && key != null && key == artKey && artBitmap != null) rv.setImageViewBitmap(R.id.w_art, artBitmap)
        else if (!has) rv.setImageViewResource(R.id.w_art, R.drawable.ic_splash_logo)

        rv.setOnClickPendingIntent(R.id.w_root, openApp(ctx))
        rv.setOnClickPendingIntent(R.id.w_art, openApp(ctx))
        if (p != null) {
            rv.setOnClickPendingIntent(R.id.w_play, broadcast(ctx, ACTION_PLAY_PAUSE))
            rv.setOnClickPendingIntent(R.id.w_next, broadcast(ctx, ACTION_NEXT))
            rv.setOnClickPendingIntent(R.id.w_prev, broadcast(ctx, ACTION_PREV))
        } else {
            // player not running yet: any button just opens the app
            val open = openApp(ctx)
            rv.setOnClickPendingIntent(R.id.w_play, open)
            rv.setOnClickPendingIntent(R.id.w_next, open)
            rv.setOnClickPendingIntent(R.id.w_prev, open)
        }
        manager.updateAppWidget(all, rv)

        // cover is loaded in the background, then pushed
        if (has && key != null && key != artKey) {
            scope.launch {
                val bmp = runCatching { loadRounded(ctx, key) }.getOrNull() ?: return@launch
                artKey = key; artBitmap = bmp
                val r2 = RemoteViews(ctx.packageName, R.layout.widget_player)
                r2.setImageViewBitmap(R.id.w_art, bmp)
                runCatching { manager.partiallyUpdateAppWidget(ids(ctx), r2) }
            }
        }
    }

    /** Cheap once-a-second refresh of the progress bar and time only. */
    fun tick(ctx: Context, p: Player) {
        val all = ids(ctx)
        if (all.isEmpty()) return
        val rv = RemoteViews(ctx.packageName, R.layout.widget_player)
        applyProgress(rv, p)
        AppWidgetManager.getInstance(ctx).partiallyUpdateAppWidget(all, rv)
    }

    private fun applyProgress(rv: RemoteViews, p: Player?) {
        val dur = p?.duration?.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
        val pos = (p?.currentPosition ?: 0L).coerceIn(0L, if (dur > 0) dur else Long.MAX_VALUE)
        rv.setProgressBar(R.id.w_progress, 1000, if (dur > 0) (pos * 1000 / dur).toInt() else 0, false)
        rv.setTextViewText(R.id.w_time, if (dur > 0) "${fmt(pos)} / ${fmt(dur)}" else fmt(pos))
    }

    private suspend fun loadRounded(ctx: Context, url: String): Bitmap? {
        val px = 280
        val req = ImageRequest.Builder(ctx).data(url).size(px, px).scale(Scale.FILL).precision(Precision.EXACT)
            .allowHardware(false).build()
        val src = (ctx.imageLoader.execute(req).drawable as? BitmapDrawable)?.bitmap ?: return null
        val scaled = Bitmap.createScaledBitmap(src, px, px, true)
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        Canvas(out).drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), px * 0.22f, px * 0.22f, paint)
        return out
    }
}
